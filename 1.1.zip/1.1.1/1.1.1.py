import pandas as pd
import numpy as np

# 读取数据集 1分
data = _____________  # pd.read_csv('patient_data.csv')
# 1. 统计住院天数超过7天的患者数量及其占比
# 创建新列'RiskLevel'，根据住院天数判断风险等级 3分
_____________ = _____________(_____________, '高风险患者', '低风险患者')  # data['RiskLevel'], np.where, data['DaysInHospital'] > 7
# 统计不同风险等级的患者数量 2分
risk_counts = data_____________._____________  # ['RiskLevel'], value_counts()
# 计算高风险患者占比 1分
high_risk_ratio = risk_counts['高风险患者'] / _____________  # len(data)
# 计算低风险患者占比 1分
low_risk_ratio = risk_counts['低风险患者'] / _____________  # len(data)

# 输出结果
print("高风险患者数量:", risk_counts['高风险患者'])
print("低风险患者数量:", risk_counts['低风险患者'])
print("高风险患者占比:", high_risk_ratio)
print("低风险患者占比:", low_risk_ratio)
# 2. 统计不同BMI区间中高风险患者的比例和统计不同BMI区间中的患者数
# 定义BMI区间和标签
bmi_bins = [0, 18.5, 24, 28, np.inf]
bmi_labels = ['偏瘦', '正常', '超重', '肥胖']
# 根据BMI值划分指定区间 4分
data['BMIRange'] = _____________(_____________, _____________, _____________, right=False)  # pd.cut, data['BMI'], bins=bmi_bins, labels=bmi_labels
# 计算每个BMI区间中高风险患者的比例 2分
bmi_risk_rate = _____________(_____________)['RiskLevel'].apply(lambda x: (x == '高风险患者').mean())  # data.groupby, 'BMIRange'
# 统计每个BMI区间的患者数量 1分
bmi_patient_count = data_____________  # ['BMIRange'].value_counts()

# 输出结果
print("BMI区间中高风险患者的比例和患者数:")
print(bmi_risk_rate) 
print(bmi_patient_count)
# 3. 统计不同年龄区间中高风险患者的比例和统计不同年龄区间中的患者数
# 定义年龄区间和标签
age_bins = [0, 26, 36, 46, 56, 66, np.inf]
age_labels = ['≤25岁', '26-35岁', '36-45岁', '46-55岁', '56-65岁', '＞65岁']
# 根据年龄值划分指定区间 4分
data['AgeRange'] = pd.cut(data['Age'], bins=age_bins, labels=age_labels, right=False)  # pd.cut, data['Age'], bins=age_bins, labels=age_labels
# 计算每个年龄区间中高风险患者的比例 2分
age_risk_rate = _____________(_____________)['RiskLevel'].apply(lambda x: (x == '高风险患者').mean())  # data.groupby, 'AgeRange'
# 统计每个年龄区间的患者数量 1分
age_patient_count = data_____________  # ['AgeRange'].value_counts()

# 输出结果
print("年龄区间中高风险患者的比例和患者数:")
print(age_risk_rate) 
print(age_patient_count) 
